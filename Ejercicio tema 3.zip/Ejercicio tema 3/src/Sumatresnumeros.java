public class Sumatresnumeros {
    public Sumatresnumeros() {
    }

    public static void main(String[] args) {
        int a = 33;
        int b = 57;
        int c = 10;
        int resultado = Sumatresnumeros(a, b, c);
        System.out.println("La suma de las tres variables es: " + resultado);
    }

    public static int Sumatresnumeros(int a, int b, int c) {
        int resultado = a + b + c;
        return resultado;
    }
}