
public class Automovil {
    private int numPuertas;

    public Automovil(int numPuertas) {
        this.numPuertas = numPuertas;
    }

    public void anadirPuertas() {
        numPuertas++;
    }

    public int getNumPuertas() {
        return numPuertas;
    }


    public static void main(String[] args) {
        Automovil miAutomovil = new Automovil(4);
        miAutomovil.anadirPuertas();
        System.out.println("Mi auto tiene " + miAutomovil.getNumPuertas() + " puertas.");
    }
}