public class Tema8 {

    //Objeto persona en el main
    public static void main(String[] args) {
        Persona persona = new Persona();

        //Usar los gets y los setts para dar valores a las propiedades

        persona.setEdad(29);
        persona.setNombre("Paola Lopez");
        persona.setTelefono("667888999");

        //Imprimir en la consola (en 2 pasos como en la clase)
        int edad = persona.getEdad();
        String nombre = persona.getNombre();
        String telefono = persona.getTelefono();
        System.out.println("Edad: " + edad);
        System.out.println("Nombre: " + nombre);
        System.out.println("Telefono: " + telefono);
    }
}

class Persona {

    //Variables privadas de la clase persona
    private int edad;
    private String nombre;
    private String telefono;

    //Getters

    public int getEdad() {
        return this.edad;
    }
    public String getNombre() {
        return this.nombre;
    }
    public String getTelefono() {
        return this.telefono;
    }

    //Setters

    public void setEdad(int edad) {
        this.edad = edad;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

}