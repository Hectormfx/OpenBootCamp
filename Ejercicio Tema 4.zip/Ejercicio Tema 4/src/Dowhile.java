public class Dowhile {
    public static void main(String[] args) {
        int numero = 4;

        do {
            numero++;
            System.out.println(numero);
        } while (numero < 3);
    }
}

