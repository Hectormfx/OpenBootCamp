public class SWITCH {
    public static void main(String[] args) {
        String estacion = "Verano";

        switch (estacion) {
            case "Primavera":
                System.out.println("Estamos en PRIMAVERA");
                break;
            case "Verano":
                System.out.println("Estamos en VERANO");
                break;
            case "Otoño":
                System.out.println("Estamos en OTOÑO");
                break;
            case "Invierno":
                System.out.println("Estamos en INVIERNO");
                break;
            default:
                System.out.println("El valor de la variable °estacion° no es una estación del año");
                break;
        }
    }
}
