public class FOR {
    public static void main(String[] args) {
        for (int NumeroFor = 0; NumeroFor <= 3; NumeroFor++) {
            System.out.println(NumeroFor);
        }
    }
}
