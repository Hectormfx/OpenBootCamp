public class NumeroPositivoNegativo {
    public static void main(String[] args){
        int numero = -9;
                if (numero < 0) {
                    System.out.println("El numero es negatvio");
                } else if (numero > 0) {
                    System.out.println("El numero es positivo");
                } else {
                    System.out.println("El numero es 0.");
                }
    }
}