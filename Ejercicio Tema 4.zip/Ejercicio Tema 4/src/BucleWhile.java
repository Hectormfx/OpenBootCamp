public class BucleWhile {
    public static void main(String[] args) {
        int numero = 0;

        while (numero < 3) {
            numero++;
            System.out.println(numero);
        }
    }
}
