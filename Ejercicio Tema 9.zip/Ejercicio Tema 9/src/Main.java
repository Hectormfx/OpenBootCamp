import java.sql.SQLOutput;

public class Main {
    public static void main(String[] args) {
        Cliente cliente = new Cliente(35, "Edgardo", "+52669874", 500000);
        System.out.println("Cliente: ");
        System.out.println("Nombre: " + cliente.nombre);
        System.out.println("Edad: " + cliente.edad);
        System.out.println("Telefono: " + cliente.telefono);
        System.out.println("Credito: " + cliente.credito);


    }
}

class Persona {
    int edad;
    String nombre;
    String telefono;
    public Persona(int edad, String nombre, String telefono){
        this.edad = edad;
        this.nombre = nombre;
        this.telefono = telefono;
    }
}

class Cliente extends Persona {
    int credito;
    public Cliente(int edad, String nombre, String telefono, int credito){
        super(edad, nombre, telefono);
        this.credito = credito;
    }
}

class Trabajador extends Persona {
    int salario;
            public Trabajador(int edad, String nombre, String telefono, int salario){
    super(edad, nombre, telefono);
    this.salario = salario;
            }
}